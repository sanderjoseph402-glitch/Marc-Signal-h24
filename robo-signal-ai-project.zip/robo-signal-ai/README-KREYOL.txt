ROBO SIGNAL AI — ENSTRIKSYON

PWOJÈ SA A GEN:
- index.html: paj aplikasyon an
- netlify/functions/analyze.js: backend ki voye screenshot la bay AI a
- netlify.toml: paramèt Netlify

ENPÒTAN: AI a pap mache jiskaske ou mete yon kle API ki gen aksè ak kredi/billing sou OpenAI Platform.

ETAP 1 — METE DOSYE YO SOU GITHUB
1. Louvri repository GitHub ki konekte ak sit Netlify ou a.
2. Ranplase ansyen HTML la ak kontni index.html sa a (ou ka rele fichye a index.html).
3. Ajoute dosye netlify.toml nan rasin pwojè a.
4. Kreye dosye netlify/functions/ epi mete analyze.js ladan.
5. Commit chanjman yo. Asire Netlify ap redeploy repository a.

ETAP 2 — METE KLE API A SOU NETLIFY
1. Louvri Netlify epi antre nan sit ou a.
2. Ale nan Site configuration (oswa Project configuration) > Environment variables.
3. Ajoute yon variable:
   Key: OPENAI_API_KEY
   Value: kle API pa w la
4. Sove li epi redeploy sit la pou nouvo variable la pran efè.

Pa janm kole kle API a nan index.html, nan chat piblik, oswa nan GitHub. Pa pataje kle a ak pèsonn.

ETAP 3 — TESTE
1. Louvri sit Netlify a apre deploy la fini.
2. Chwazi yon screenshot graf ki pi piti pase 8 MB.
3. Chwazi pè a ak tan bouji a.
4. Peze “Analize ak AI”.

SI LI PA MACHE
- Verifye deploy la fini san erè.
- Verifye dosye a rele egzakteman netlify/functions/analyze.js.
- Verifye OPENAI_API_KEY la byen mete epi kont API a gen aksè/kredi.
- Gade Netlify Functions logs pou mesaj erè.

NÒT: Sa se analiz vizyèl edikatif. AI a ka mal li screenshot la. BUY/SELL/WAIT pa garanti pwofi; teste sou demo epi pa riske lajan ou pa ka pèdi.
