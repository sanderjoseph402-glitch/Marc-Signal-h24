exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store"
  };
  const reply = (statusCode, body) => ({
    statusCode,
    headers,
    body: JSON.stringify(body)
  });

  if (event.httpMethod !== "POST") {
    return reply(405, { error: "Metòd sa a pa disponib." });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return reply(500, { error: "OPENAI_API_KEY poko mete nan anviwònman Netlify la." });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return reply(400, { error: "Done yo pa valab." });
  }

  const { image, pair, timeframe } = payload;
  if (typeof image !== "string" || !/^data:image\/(png|jpeg|webp);base64,/.test(image)) {
    return reply(400, { error: "Voye yon screenshot PNG, JPG oswa WebP." });
  }
  if (image.length > 11_500_000) {
    return reply(413, { error: "Foto a twò gwo. Chwazi yon foto ki pi piti." });
  }

  const prompt = `Ou se yon asistan edikatif ki dekri screenshot graf finansye. Mache: ${String(pair || "Pa konnen").slice(0,80)}. Tan bouji: ${String(timeframe || "Pa konnen").slice(0,40)}.
Egzamine imaj la sèlman. Pa envante pri, endikatè, oswa done ki pa lizib. Bay yon analiz pridan, pa yon garanti oswa konsèy finansye pèsonalize. Si imaj la twoub, pa gen ase enfòmasyon, oswa direksyon an pa klè, chwazi WAIT. BUY/SELL se yon opinyon vizyèl ensèten sèlman. Reponn an Kreyòl Ayisyen kòm JSON valab ak kle sa yo:
{"signal":"BUY oswa SELL oswa WAIT","confidence":"Ba, Mwayen, oswa Wo","summary":"yon fraz kout","analysis":"eksplike tandans vizib la, sa ki sipòte lekti a, sa ki pa klè, epi risk yo. Pa plis pase 150 mo."}`;

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        input: [{
          role: "user",
          content: [
            { type: "input_text", text: prompt },
            { type: "input_image", image_url: image, detail: "high" }
          ]
        }],
        text: { format: { type: "json_object" } },
        max_output_tokens: 500
      })
    });

    const result = await upstream.json();
    if (!upstream.ok) {
      console.error("OpenAI API error:", result.error?.message || upstream.status);
      return reply(502, { error: "Sèvis AI a pa reponn. Verifye kle API a, kredi API a, epi eseye ankò." });
    }

    const outputText = (result.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n");

    let parsed;
    try {
      parsed = JSON.parse(outputText);
    } catch {
      return reply(502, { error: "AI a pa retounen yon repons nou ka li. Eseye ankò." });
    }

    const allowed = ["BUY", "SELL", "WAIT"];
    const signal = allowed.includes(String(parsed.signal).toUpperCase())
      ? String(parsed.signal).toUpperCase()
      : "WAIT";

    return reply(200, {
      signal,
      confidence: ["Ba", "Mwayen", "Wo"].includes(parsed.confidence) ? parsed.confidence : "Ba",
      summary: String(parsed.summary || "AI a fini analiz la.").slice(0, 240),
      analysis: String(parsed.analysis || "Pa gen detay disponib.").slice(0, 1800)
    });
  } catch (error) {
    console.error("Analysis function error:", error.message);
    return reply(500, { error: "Erè sèvè. Verifye paramèt Netlify yo epi eseye ankò." });
  }
};
